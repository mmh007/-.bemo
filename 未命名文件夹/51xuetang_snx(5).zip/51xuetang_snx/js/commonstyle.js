$(function ($) {
  
  // 筛选地区点击事件
  $('.left-module-wrapper .module-card-wrapper li').click(function() {
    $(this).addClass('select-tag a').siblings().removeClass('select-tag a')
  })
  

  // 筛选学校点击事件
  $('.hot-school li').click(function() {
    $(this).addClass('select-tag a').siblings().removeClass('select-tag a');
  })


  // 二维码显示隐藏
  $('.hot-school ul li a').click(function () { 
    $(this).addClass('div .qr-code').siblings('div .qr-code').show();
  });
  $('.hot-school li').mouseout(function () { 
    $('div .qr-code').hide();
  });

  // 关于我们显示切换 
  $('.aboutUs-wrapper .aboutUs-left li').click(function() {
    var index = $(this).index()
    // $(this).addClass('active').siblings().removeClass('active');
    // $('.aboutUs-right .module-card').eq(index).fadeIn().siblings().fadeOut();
    $('.aboutUs-right .module-card').eq(index).show().siblings().hide();
    $(this).addClass('card-span span').siblings().removeClass('card-span span').show();
  })
})
// 圆形按钮
$('.aboutUs-wrapper .aboutUs-left li').click(function() {
  $(this).find('.roundness-card').show()
  $(this).siblings().find('.roundness-card').hide();
})


// 输入框激活状态
$('.form-input-wrapper input').focus(function() {
  $(this).addClass('red');
})

$('.form-input-wrapper input').blur(function() {
  $(this).removeClass('red');
})