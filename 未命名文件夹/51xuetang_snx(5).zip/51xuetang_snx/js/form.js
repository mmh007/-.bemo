$(function($) {
  var regEn = /[`~!@#$%^&*_+<>?:"{},.\/;'[\]]/im;
  var regCn = /[·！#￥——：；“”‘、，|《。》？、【】[\]]/im;
  var regEmoji = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/im;
  var regPhone = /^1[3|4|5|7|8][0-9]{9}$/;
  var query = {
    company: null,
    phone: null
 }
  // 1.公司、机构名称验证
 $('#company').blur(companyValidator);
 	// 2.手机号码
 $('#phone').blur(phoneValidator);

 // 1. 公司、机构名称验证
 function companyValidator() {
   //定义正则表达式
		var $val = $('#company').val();
    query.company = $val;
  //1.不能为空
  if($val === '' || $val === null){
    $(this).parent().addClass('.error-wrapper').find('.verification-card span').text('所填内容不能为空').siblings().removeClass().show();
    return false
  }
  // 2.格式
  else if(regCn.test($val) || regEn.test($val) || regEmoji.test($val)) {
    $(this).parent().addClass('.error-wrapper').find('.verification-card span').text('请输入正确格式');
    return false
  }
  // 3. 输入正确
  else{
    $(this).parent().removeClass('.error-wrapper').find('.verification-card span').text('')
    return true
  }};

  // 2.手机号码
  function phoneValidator() {
    //定义正则表达式
		var $val = $('#phone').val();
		query.phone = $val;
    // 1. 不能为空
    if($val == '' || $val == null){
      $(this).parent().addClass('error-wrapper').find('.verification-card span').text('请检查输入格式是否有误').siblings().removeClass().show();
      return false
    }
    // 2.格式
    else if(!regPhone.test($val)){
			$(this).parent().addClass('error-wrapper').find('.verification-card span').text('请输入正确格式的手机号码');
			return false
    }
    // 3. 输入正确
		else{
			$(this).parent().removeClass('error-wrapper').find('.verification-card span').text('');
			return true
		}
  }
})